DADI NANI KESH TEL — RAZORPAY READY

This project keeps the Razorpay Secret on the server. Do NOT put the secret in index.html.

1. Install Node.js on your hosting/server.
2. Copy .env.example to .env.
3. Put your Razorpay TEST Key ID and TEST Key Secret in .env.
4. Run: npm install
5. Run: npm start
6. Open the site and test a payment in Razorpay Test Mode.
7. Only after testing and account verification, replace test credentials with LIVE credentials on the server.

Important:
- The website charges ₹470 at checkout: ₹400 product + ₹20 GST + ₹50 delivery.
- Real payment processing requires a server and HTTPS.
- The Secret must never be shared in chat or placed in frontend code.
