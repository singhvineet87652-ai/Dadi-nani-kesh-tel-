require("dotenv").config();\nconst express = require("express");
const Razorpay = require("razorpay");
const path = require("path");
const crypto = require("crypto");

const app = express();
app.use(express.json());
app.use(express.static(__dirname));

const keyId = process.env.RAZORPAY_KEY_ID;
const keySecret = process.env.RAZORPAY_KEY_SECRET;

if (!keyId || !keySecret) {
  console.warn("Razorpay keys are not configured. Add them to environment variables before testing payments.");
}

const razorpay = new Razorpay({
  key_id: keyId || "missing",
  key_secret: keySecret || "missing"
});

app.post("/api/create-order", async (req, res) => {
  try {
    // ₹400 product + ₹20 GST + ₹50 delivery = ₹470
    const order = await razorpay.orders.create({
      amount: 47000,
      currency: "INR",
      receipt: "DNK_" + Date.now(),
      notes: { product: "Dadi Nani Kesh Tel 100ml" },
      payment_capture: 1
    });
    res.json({ ok: true, order, keyId });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, error: "Payment order could not be created." });
  }
});

app.post("/api/verify-payment", (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
    const expected = crypto
      .createHmac("sha256", keySecret)
      .update(razorpay_order_id + "|" + razorpay_payment_id)
      .digest("hex");

    const valid = crypto.timingSafeEqual(
      Buffer.from(expected),
      Buffer.from(razorpay_signature || "")
    );

    if (!valid) return res.status(400).json({ ok: false, error: "Invalid payment signature." });

    res.json({
      ok: true,
      status: "Payment verified",
      orderId: razorpay_order_id,
      paymentId: razorpay_payment_id
    });
  } catch (e) {
    res.status(400).json({ ok: false, error: "Payment verification failed." });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.listen(process.env.PORT || 3000, () => {
  console.log("Dadi Nani store running");
});
